//
//  ViewController.swift
//  Toasting
//
//  Created by Apple on 11/11/19.
//  Copyright © 2019 appzoo. All rights reserved.
//  https://github.com/devxoul/Toaster

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func clickToast(_ sender: Any) {
        if let currentToast = ToastCenter.default.currentToast {
            currentToast.cancel()
        }
        
        Toast(text: "Select Project!", duration: Delay.long).show()
        ToastView.appearance().cornerRadius = 14
    }
}

